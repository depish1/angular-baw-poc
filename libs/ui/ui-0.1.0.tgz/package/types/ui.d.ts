import * as _angular_core from '@angular/core';
import { FormValueControl, ValidationError } from '@angular/forms/signals';

type ButtonVariant = 'primary' | 'secondary';
type ButtonSize = 'default' | 'mini';
declare class UiButton {
    readonly variant: _angular_core.InputSignal<ButtonVariant>;
    readonly size: _angular_core.InputSignal<ButtonSize>;
    readonly type: _angular_core.InputSignal<"button" | "submit" | "reset">;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly clicked: _angular_core.OutputEmitterRef<MouseEvent>;
    protected handleClick(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiButton, "ui-button", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "clicked": "clicked"; }, never, ["*"], true, never>;
}

type AlertVariant = 'info' | 'success' | 'warning' | 'error';
declare class UiAlert {
    readonly variant: _angular_core.InputSignal<AlertVariant>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiAlert, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiAlert, "ui-alert", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type InputType = 'text' | 'search' | 'email' | 'password';
type InputSize = 'default' | 'mini';
declare class UiInput implements FormValueControl<string> {
    readonly value: _angular_core.ModelSignal<string>;
    readonly type: _angular_core.InputSignal<InputType>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly size: _angular_core.InputSignal<InputSize>;
    readonly id: _angular_core.InputSignal<string>;
    readonly describedBy: _angular_core.InputSignal<string>;
    readonly touched: _angular_core.ModelSignal<boolean>;
    private readonly control;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiInput, "ui-input", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "describedBy": { "alias": "describedBy"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

declare class UiLabel {
    readonly forId: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiLabel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiLabel, "ui-label", never, { "forId": { "alias": "for"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class UiError {
    readonly message: _angular_core.InputSignal<string>;
    readonly id: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiError, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiError, "ui-error", never, { "message": { "alias": "message"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class UiFormFieldInput implements FormValueControl<string> {
    readonly label: _angular_core.InputSignal<string>;
    readonly value: _angular_core.ModelSignal<string>;
    readonly type: _angular_core.InputSignal<InputType>;
    readonly size: _angular_core.InputSignal<InputSize>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.ModelSignal<boolean>;
    readonly errors: _angular_core.InputSignal<readonly ValidationError.WithOptionalFieldTree[]>;
    protected readonly controlId: string;
    protected readonly errorId: string;
    private readonly control;
    protected showError(): boolean;
    protected errorMessage(): string;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiFormFieldInput, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiFormFieldInput, "ui-form-field-input", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

declare class UiCheckbox implements FormValueControl<boolean> {
    readonly value: _angular_core.ModelSignal<boolean>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.ModelSignal<boolean>;
    readonly id: _angular_core.InputSignal<string>;
    readonly describedBy: _angular_core.InputSignal<string>;
    private readonly control;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiCheckbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiCheckbox, "ui-checkbox", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "describedBy": { "alias": "describedBy"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, ["*"], true, never>;
}

declare class UiFormFieldCheckbox implements FormValueControl<boolean> {
    readonly label: _angular_core.InputSignal<string>;
    readonly value: _angular_core.ModelSignal<boolean>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.ModelSignal<boolean>;
    readonly errors: _angular_core.InputSignal<readonly ValidationError.WithOptionalFieldTree[]>;
    protected readonly controlId: string;
    protected readonly errorId: string;
    private readonly control;
    protected showError(): boolean;
    protected errorMessage(): string;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiFormFieldCheckbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiFormFieldCheckbox, "ui-form-field-checkbox", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

type GroupOrientation = 'vertical' | 'horizontal';
declare class UiCheckboxGroup<T extends object> implements FormValueControl<T[]> {
    readonly options: _angular_core.InputSignal<readonly T[]>;
    readonly labelKey: _angular_core.InputSignal<keyof T>;
    readonly valueKey: _angular_core.InputSignal<keyof T>;
    readonly value: _angular_core.ModelSignal<T[]>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.ModelSignal<boolean>;
    readonly orientation: _angular_core.InputSignal<GroupOrientation>;
    readonly labelledBy: _angular_core.InputSignal<string>;
    private readonly host;
    protected isSelected(option: T): boolean;
    protected setSelection(option: T, selected: boolean): void;
    protected onFocusOut(event: FocusEvent): void;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiCheckboxGroup<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiCheckboxGroup<any>, "ui-checkbox-group", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "valueKey": { "alias": "valueKey"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "labelledBy": { "alias": "labelledBy"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

declare class UiFormFieldCheckboxGroup<T extends object> implements FormValueControl<T[]> {
    readonly label: _angular_core.InputSignal<string>;
    readonly options: _angular_core.InputSignal<readonly T[]>;
    readonly labelKey: _angular_core.InputSignal<keyof T>;
    readonly valueKey: _angular_core.InputSignal<keyof T>;
    readonly orientation: _angular_core.InputSignal<GroupOrientation>;
    readonly value: _angular_core.ModelSignal<T[]>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.ModelSignal<boolean>;
    readonly errors: _angular_core.InputSignal<readonly ValidationError.WithOptionalFieldTree[]>;
    protected readonly labelId: string;
    private readonly control;
    protected showError(): boolean;
    protected errorMessage(): string;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiFormFieldCheckboxGroup<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiFormFieldCheckboxGroup<any>, "ui-form-field-checkbox-group", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "valueKey": { "alias": "valueKey"; "required": true; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

declare class UiRadioGroup<T extends object> implements FormValueControl<T | null> {
    readonly options: _angular_core.InputSignal<readonly T[]>;
    readonly labelKey: _angular_core.InputSignal<keyof T>;
    readonly valueKey: _angular_core.InputSignal<keyof T>;
    readonly value: _angular_core.ModelSignal<T | null>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.ModelSignal<boolean>;
    readonly orientation: _angular_core.InputSignal<GroupOrientation>;
    readonly labelledBy: _angular_core.InputSignal<string>;
    protected readonly groupName: string;
    private readonly host;
    protected isSelected(option: T): boolean;
    protected select(option: T): void;
    protected onFocusOut(event: FocusEvent): void;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiRadioGroup<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiRadioGroup<any>, "ui-radio-group", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "valueKey": { "alias": "valueKey"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "labelledBy": { "alias": "labelledBy"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

declare class UiFormFieldRadioGroup<T extends object> implements FormValueControl<T | null> {
    readonly label: _angular_core.InputSignal<string>;
    readonly options: _angular_core.InputSignal<readonly T[]>;
    readonly labelKey: _angular_core.InputSignal<keyof T>;
    readonly valueKey: _angular_core.InputSignal<keyof T>;
    readonly orientation: _angular_core.InputSignal<GroupOrientation>;
    readonly value: _angular_core.ModelSignal<T | null>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.ModelSignal<boolean>;
    readonly errors: _angular_core.InputSignal<readonly ValidationError.WithOptionalFieldTree[]>;
    protected readonly labelId: string;
    private readonly control;
    protected showError(): boolean;
    protected errorMessage(): string;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UiFormFieldRadioGroup<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UiFormFieldRadioGroup<any>, "ui-form-field-radio-group", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "labelKey": { "alias": "labelKey"; "required": true; "isSignal": true; }; "valueKey": { "alias": "valueKey"; "required": true; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touched": "touchedChange"; }, never, never, true, never>;
}

export { UiAlert, UiButton, UiCheckbox, UiCheckboxGroup, UiError, UiFormFieldCheckbox, UiFormFieldCheckboxGroup, UiFormFieldInput, UiFormFieldRadioGroup, UiInput, UiLabel, UiRadioGroup };
export type { AlertVariant, ButtonSize, ButtonVariant, GroupOrientation, InputSize, InputType };
//# sourceMappingURL=ui.d.ts.map
