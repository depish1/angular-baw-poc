import * as i0 from '@angular/core';
import { input, output, Component, model, viewChild, inject, ElementRef } from '@angular/core';

class UiButton {
    constructor() {
        this.variant = input('primary', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
        this.size = input('default', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
        this.type = input('button', ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
        this.disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
        this.clicked = output();
    }
    handleClick(event) {
        if (!this.disabled())
            this.clicked.emit(event);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiButton, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.26", type: UiButton, isStandalone: true, selector: "ui-button", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { clicked: "clicked" }, ngImport: i0, template: "<button\n  [type]=\"type()\"\n  [disabled]=\"disabled()\"\n  [class.ui-button--primary]=\"variant() === 'primary'\"\n  [class.ui-button--secondary]=\"variant() === 'secondary'\"\n  [class.ui-button--mini]=\"size() === 'mini'\"\n  (click)=\"handleClick($event)\"\n>\n  <ng-content />\n</button>\n", styles: [":host{display:inline-block}button{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;min-height:38px;padding:var(--ui-spacing-sm, 8px) var(--ui-spacing-md, 12px);border:1px solid transparent;border-radius:var(--ui-radius, 6px);font:inherit;font-weight:600;line-height:1.25;cursor:pointer}.ui-button--primary{background:var(--ui-color-primary, #b42318);color:var(--ui-color-on-primary, #fff)}.ui-button--primary:hover:not(:disabled){background:var(--ui-color-primary-hover, #912018)}.ui-button--secondary{background:var(--ui-color-surface, #fff);color:var(--ui-color-text, #222);border-color:var(--ui-color-border, #8d929a)}.ui-button--secondary:hover:not(:disabled){background:var(--ui-color-surface-hover, #f3f4f6)}.ui-button--mini{min-height:26px;padding:var(--ui-spacing-xs, 4px) var(--ui-spacing-sm, 8px);font-size:.8125rem}button:focus-visible{outline:3px solid var(--ui-color-focus, #2563eb);outline-offset:2px}button:disabled{cursor:not-allowed;opacity:.55}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiButton, decorators: [{
            type: Component,
            args: [{ selector: 'ui-button', template: "<button\n  [type]=\"type()\"\n  [disabled]=\"disabled()\"\n  [class.ui-button--primary]=\"variant() === 'primary'\"\n  [class.ui-button--secondary]=\"variant() === 'secondary'\"\n  [class.ui-button--mini]=\"size() === 'mini'\"\n  (click)=\"handleClick($event)\"\n>\n  <ng-content />\n</button>\n", styles: [":host{display:inline-block}button{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;min-height:38px;padding:var(--ui-spacing-sm, 8px) var(--ui-spacing-md, 12px);border:1px solid transparent;border-radius:var(--ui-radius, 6px);font:inherit;font-weight:600;line-height:1.25;cursor:pointer}.ui-button--primary{background:var(--ui-color-primary, #b42318);color:var(--ui-color-on-primary, #fff)}.ui-button--primary:hover:not(:disabled){background:var(--ui-color-primary-hover, #912018)}.ui-button--secondary{background:var(--ui-color-surface, #fff);color:var(--ui-color-text, #222);border-color:var(--ui-color-border, #8d929a)}.ui-button--secondary:hover:not(:disabled){background:var(--ui-color-surface-hover, #f3f4f6)}.ui-button--mini{min-height:26px;padding:var(--ui-spacing-xs, 4px) var(--ui-spacing-sm, 8px);font-size:.8125rem}button:focus-visible{outline:3px solid var(--ui-color-focus, #2563eb);outline-offset:2px}button:disabled{cursor:not-allowed;opacity:.55}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], clicked: [{ type: i0.Output, args: ["clicked"] }] } });

class UiAlert {
    constructor() {
        this.variant = input('info', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiAlert, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.26", type: UiAlert, isStandalone: true, selector: "ui-alert", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.role": "variant() === 'error' ? 'alert' : 'status'", "class.ui-alert--info": "variant() === 'info'", "class.ui-alert--success": "variant() === 'success'", "class.ui-alert--warning": "variant() === 'warning'", "class.ui-alert--error": "variant() === 'error'" } }, ngImport: i0, template: `<ng-content />`, isInline: true, styles: [":host{display:block;box-sizing:border-box;padding:var(--ui-spacing-md, 12px);border:1px solid currentColor;border-radius:var(--ui-radius, 6px);font:inherit}:host(.ui-alert--info){color:var(--ui-color-info, #175cd3);background:var(--ui-color-info-background, #eff8ff)}:host(.ui-alert--success){color:var(--ui-color-success, #067647);background:var(--ui-color-success-background, #ecfdf3)}:host(.ui-alert--warning){color:var(--ui-color-warning, #93370d);background:var(--ui-color-warning-background, #fffaeb)}:host(.ui-alert--error){color:var(--ui-color-error, #b42318);background:var(--ui-color-error-background, #fef3f2)}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiAlert, decorators: [{
            type: Component,
            args: [{ selector: 'ui-alert', template: `<ng-content />`, host: {
                        '[attr.role]': "variant() === 'error' ? 'alert' : 'status'",
                        '[class.ui-alert--info]': "variant() === 'info'",
                        '[class.ui-alert--success]': "variant() === 'success'",
                        '[class.ui-alert--warning]': "variant() === 'warning'",
                        '[class.ui-alert--error]': "variant() === 'error'",
                    }, styles: [":host{display:block;box-sizing:border-box;padding:var(--ui-spacing-md, 12px);border:1px solid currentColor;border-radius:var(--ui-radius, 6px);font:inherit}:host(.ui-alert--info){color:var(--ui-color-info, #175cd3);background:var(--ui-color-info-background, #eff8ff)}:host(.ui-alert--success){color:var(--ui-color-success, #067647);background:var(--ui-color-success-background, #ecfdf3)}:host(.ui-alert--warning){color:var(--ui-color-warning, #93370d);background:var(--ui-color-warning-background, #fffaeb)}:host(.ui-alert--error){color:var(--ui-color-error, #b42318);background:var(--ui-color-error-background, #fef3f2)}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }] } });

class UiInput {
    constructor() {
        this.value = model('', ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
        this.type = input('text', ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
        this.placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
        this.disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
        this.readonly = input(false, ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
        this.invalid = input(false, ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
        this.size = input('default', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
        this.id = input('', ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
        this.describedBy = input('', ...(ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []));
        this.touched = model(false, ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
        this.control = viewChild('control', ...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    }
    focus(options) {
        this.control()?.nativeElement.focus(options);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiInput, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.26", type: UiInput, isStandalone: true, selector: "ui-input", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, describedBy: { classPropertyName: "describedBy", publicName: "describedBy", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", touched: "touchedChange" }, viewQueries: [{ propertyName: "control", first: true, predicate: ["control"], descendants: true, isSignal: true }], ngImport: i0, template: `<input #control [id]="id()" [type]="type()" [value]="value()"
    [placeholder]="placeholder()" [disabled]="disabled()" [readOnly]="readonly()"
    [attr.aria-invalid]="invalid()" [attr.aria-describedby]="describedBy() || null"
    [class.ui-input--mini]="size() === 'mini'"
    (input)="value.set($any($event.target).value)" (blur)="touched.set(true)" />`, isInline: true, styles: [":host{display:inline-block;width:100%}input{box-sizing:border-box;width:100%;padding:var(--ui-spacing-sm, 8px) var(--ui-spacing-md, 12px);border:1px solid var(--ui-color-border, #8d929a);border-radius:var(--ui-radius, 6px);background:var(--ui-color-surface, white);color:var(--ui-color-text, #222);font:inherit}input:focus-visible{outline:2px solid var(--ui-color-focus, #175cd3);outline-offset:1px}input[aria-invalid=true]{border-color:var(--ui-color-error, #b42318)}input:disabled{opacity:.6;cursor:not-allowed}input.ui-input--mini{padding:var(--ui-spacing-xs, 4px) var(--ui-spacing-sm, 8px);font-size:.875rem}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiInput, decorators: [{
            type: Component,
            args: [{ selector: 'ui-input', template: `<input #control [id]="id()" [type]="type()" [value]="value()"
    [placeholder]="placeholder()" [disabled]="disabled()" [readOnly]="readonly()"
    [attr.aria-invalid]="invalid()" [attr.aria-describedby]="describedBy() || null"
    [class.ui-input--mini]="size() === 'mini'"
    (input)="value.set($any($event.target).value)" (blur)="touched.set(true)" />`, styles: [":host{display:inline-block;width:100%}input{box-sizing:border-box;width:100%;padding:var(--ui-spacing-sm, 8px) var(--ui-spacing-md, 12px);border:1px solid var(--ui-color-border, #8d929a);border-radius:var(--ui-radius, 6px);background:var(--ui-color-surface, white);color:var(--ui-color-text, #222);font:inherit}input:focus-visible{outline:2px solid var(--ui-color-focus, #175cd3);outline-offset:1px}input[aria-invalid=true]{border-color:var(--ui-color-error, #b42318)}input:disabled{opacity:.6;cursor:not-allowed}input.ui-input--mini{padding:var(--ui-spacing-xs, 4px) var(--ui-spacing-sm, 8px);font-size:.875rem}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], describedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "describedBy", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }, { type: i0.Output, args: ["touchedChange"] }], control: [{ type: i0.ViewChild, args: ['control', { isSignal: true }] }] } });

class UiLabel {
    constructor() {
        this.forId = input('', { ...(ngDevMode ? { debugName: "forId" } : /* istanbul ignore next */ {}), alias: 'for' });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiLabel, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.26", type: UiLabel, isStandalone: true, selector: "ui-label", inputs: { forId: { classPropertyName: "forId", publicName: "for", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `<label [attr.for]="forId() || null"><ng-content /></label>`, isInline: true, styles: [":host{display:block;margin-bottom:var(--ui-spacing-xs, 4px);font-weight:600}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiLabel, decorators: [{
            type: Component,
            args: [{ selector: 'ui-label', template: `<label [attr.for]="forId() || null"><ng-content /></label>`, styles: [":host{display:block;margin-bottom:var(--ui-spacing-xs, 4px);font-weight:600}\n"] }]
        }], propDecorators: { forId: [{ type: i0.Input, args: [{ isSignal: true, alias: "for", required: false }] }] } });

class UiError {
    constructor() {
        this.message = input('', ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
        this.id = input('', ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiError, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.26", type: UiError, isStandalone: true, selector: "ui-error", inputs: { message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `@if (message()) { <span [id]="id()" role="alert">{{ message() }}</span> }`, isInline: true, styles: [":host{display:block;margin-top:var(--ui-spacing-xs, 4px);color:var(--ui-color-error, #b42318);font-size:.875rem}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiError, decorators: [{
            type: Component,
            args: [{ selector: 'ui-error', template: `@if (message()) { <span [id]="id()" role="alert">{{ message() }}</span> }`, styles: [":host{display:block;margin-top:var(--ui-spacing-xs, 4px);color:var(--ui-color-error, #b42318);font-size:.875rem}\n"] }]
        }], propDecorators: { message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }] } });

let nextInputId = 0;
class UiFormFieldInput {
    constructor() {
        this.label = input.required(...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
        this.value = model('', ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
        this.type = input('text', ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
        this.size = input('default', ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
        this.placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
        this.disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
        this.readonly = input(false, ...(ngDevMode ? [{ debugName: "readonly" }] : /* istanbul ignore next */ []));
        this.invalid = input(false, ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
        this.touched = model(false, ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
        this.errors = input([], ...(ngDevMode ? [{ debugName: "errors" }] : /* istanbul ignore next */ []));
        this.controlId = `ui-input-${++nextInputId}`;
        this.errorId = `${this.controlId}-error`;
        this.control = viewChild(UiInput, ...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    }
    showError() {
        return this.touched() && this.invalid() && this.errors().length > 0;
    }
    errorMessage() {
        return this.errors()[0]?.message ?? '';
    }
    focus(options) {
        this.control()?.focus(options);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiFormFieldInput, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.26", type: UiFormFieldInput, isStandalone: true, selector: "ui-form-field-input", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, errors: { classPropertyName: "errors", publicName: "errors", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", touched: "touchedChange" }, viewQueries: [{ propertyName: "control", first: true, predicate: UiInput, descendants: true, isSignal: true }], ngImport: i0, template: `
    <ui-label [for]="controlId">{{ label() }}</ui-label>
    <ui-input [id]="controlId" [type]="type()" [size]="size()" [placeholder]="placeholder()"
      [disabled]="disabled()" [readonly]="readonly()" [invalid]="invalid()"
      [describedBy]="showError() ? errorId : ''" [value]="value()" [touched]="touched()"
      (valueChange)="value.set($event)" (touchedChange)="touched.set($event)" />
    @if (showError()) { <ui-error [id]="errorId" [message]="errorMessage()" /> }
  `, isInline: true, dependencies: [{ kind: "component", type: UiLabel, selector: "ui-label", inputs: ["for"] }, { kind: "component", type: UiInput, selector: "ui-input", inputs: ["value", "type", "placeholder", "disabled", "readonly", "invalid", "size", "id", "describedBy", "touched"], outputs: ["valueChange", "touchedChange"] }, { kind: "component", type: UiError, selector: "ui-error", inputs: ["message", "id"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiFormFieldInput, decorators: [{
            type: Component,
            args: [{
                    selector: 'ui-form-field-input',
                    imports: [UiLabel, UiInput, UiError],
                    template: `
    <ui-label [for]="controlId">{{ label() }}</ui-label>
    <ui-input [id]="controlId" [type]="type()" [size]="size()" [placeholder]="placeholder()"
      [disabled]="disabled()" [readonly]="readonly()" [invalid]="invalid()"
      [describedBy]="showError() ? errorId : ''" [value]="value()" [touched]="touched()"
      (valueChange)="value.set($event)" (touchedChange)="touched.set($event)" />
    @if (showError()) { <ui-error [id]="errorId" [message]="errorMessage()" /> }
  `,
                }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }, { type: i0.Output, args: ["touchedChange"] }], errors: [{ type: i0.Input, args: [{ isSignal: true, alias: "errors", required: false }] }], control: [{ type: i0.ViewChild, args: [i0.forwardRef(() => UiInput), { isSignal: true }] }] } });

class UiCheckbox {
    constructor() {
        this.value = model(false, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
        this.disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
        this.invalid = input(false, ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
        this.touched = model(false, ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
        this.id = input('', ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
        this.describedBy = input('', ...(ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []));
        this.control = viewChild('control', ...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    }
    focus(options) {
        this.control()?.nativeElement.focus(options);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiCheckbox, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.2.26", type: UiCheckbox, isStandalone: true, selector: "ui-checkbox", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, describedBy: { classPropertyName: "describedBy", publicName: "describedBy", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", touched: "touchedChange" }, viewQueries: [{ propertyName: "control", first: true, predicate: ["control"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <span class="ui-checkbox">
      <input #control type="checkbox" [id]="id()" [checked]="value()"
        [disabled]="disabled()" [attr.aria-invalid]="invalid()"
        [attr.aria-describedby]="describedBy() || null"
        (change)="value.set($any($event.target).checked)" (blur)="touched.set(true)" />
      <ng-content />
    </span>
  `, isInline: true, styles: [":host{display:inline-block}.ui-checkbox{display:inline-flex;align-items:center;gap:var(--ui-spacing-sm, 8px)}input{accent-color:var(--ui-color-primary, #175cd3)}input:focus-visible{outline:2px solid var(--ui-color-focus, #175cd3);outline-offset:2px}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiCheckbox, decorators: [{
            type: Component,
            args: [{ selector: 'ui-checkbox', template: `
    <span class="ui-checkbox">
      <input #control type="checkbox" [id]="id()" [checked]="value()"
        [disabled]="disabled()" [attr.aria-invalid]="invalid()"
        [attr.aria-describedby]="describedBy() || null"
        (change)="value.set($any($event.target).checked)" (blur)="touched.set(true)" />
      <ng-content />
    </span>
  `, styles: [":host{display:inline-block}.ui-checkbox{display:inline-flex;align-items:center;gap:var(--ui-spacing-sm, 8px)}input{accent-color:var(--ui-color-primary, #175cd3)}input:focus-visible{outline:2px solid var(--ui-color-focus, #175cd3);outline-offset:2px}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }, { type: i0.Output, args: ["touchedChange"] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], describedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "describedBy", required: false }] }], control: [{ type: i0.ViewChild, args: ['control', { isSignal: true }] }] } });

let nextCheckboxId = 0;
class UiFormFieldCheckbox {
    constructor() {
        this.label = input.required(...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
        this.value = model(false, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
        this.disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
        this.invalid = input(false, ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
        this.touched = model(false, ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
        this.errors = input([], ...(ngDevMode ? [{ debugName: "errors" }] : /* istanbul ignore next */ []));
        this.controlId = `ui-checkbox-${++nextCheckboxId}`;
        this.errorId = `${this.controlId}-error`;
        this.control = viewChild(UiCheckbox, ...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    }
    showError() {
        return this.touched() && this.invalid() && this.errors().length > 0;
    }
    errorMessage() {
        return this.errors()[0]?.message ?? '';
    }
    focus(options) {
        this.control()?.focus(options);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiFormFieldCheckbox, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.26", type: UiFormFieldCheckbox, isStandalone: true, selector: "ui-form-field-checkbox", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, errors: { classPropertyName: "errors", publicName: "errors", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", touched: "touchedChange" }, viewQueries: [{ propertyName: "control", first: true, predicate: UiCheckbox, descendants: true, isSignal: true }], ngImport: i0, template: `
    <ui-checkbox [id]="controlId" [value]="value()" [disabled]="disabled()"
      [invalid]="invalid()" [touched]="touched()" [describedBy]="showError() ? errorId : ''"
      (valueChange)="value.set($event)" (touchedChange)="touched.set($event)">
      <ui-label [for]="controlId">{{ label() }}</ui-label>
    </ui-checkbox>
    @if (showError()) { <ui-error [id]="errorId" [message]="errorMessage()" /> }
  `, isInline: true, styles: [":host{display:block}:host ui-label{margin:0;font-weight:400}\n"], dependencies: [{ kind: "component", type: UiCheckbox, selector: "ui-checkbox", inputs: ["value", "disabled", "invalid", "touched", "id", "describedBy"], outputs: ["valueChange", "touchedChange"] }, { kind: "component", type: UiLabel, selector: "ui-label", inputs: ["for"] }, { kind: "component", type: UiError, selector: "ui-error", inputs: ["message", "id"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiFormFieldCheckbox, decorators: [{
            type: Component,
            args: [{ selector: 'ui-form-field-checkbox', imports: [UiCheckbox, UiLabel, UiError], template: `
    <ui-checkbox [id]="controlId" [value]="value()" [disabled]="disabled()"
      [invalid]="invalid()" [touched]="touched()" [describedBy]="showError() ? errorId : ''"
      (valueChange)="value.set($event)" (touchedChange)="touched.set($event)">
      <ui-label [for]="controlId">{{ label() }}</ui-label>
    </ui-checkbox>
    @if (showError()) { <ui-error [id]="errorId" [message]="errorMessage()" /> }
  `, styles: [":host{display:block}:host ui-label{margin:0;font-weight:400}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }, { type: i0.Output, args: ["touchedChange"] }], errors: [{ type: i0.Input, args: [{ isSignal: true, alias: "errors", required: false }] }], control: [{ type: i0.ViewChild, args: [i0.forwardRef(() => UiCheckbox), { isSignal: true }] }] } });

class UiCheckboxGroup {
    constructor() {
        this.options = input([], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
        this.labelKey = input.required(...(ngDevMode ? [{ debugName: "labelKey" }] : /* istanbul ignore next */ []));
        this.valueKey = input.required(...(ngDevMode ? [{ debugName: "valueKey" }] : /* istanbul ignore next */ []));
        this.value = model([], ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
        this.disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
        this.invalid = input(false, ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
        this.touched = model(false, ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
        this.orientation = input('vertical', ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
        this.labelledBy = input('', ...(ngDevMode ? [{ debugName: "labelledBy" }] : /* istanbul ignore next */ []));
        this.host = inject(ElementRef);
    }
    isSelected(option) {
        return this.value().some((selected) => selected[this.valueKey()] === option[this.valueKey()]);
    }
    setSelection(option, selected) {
        if (this.disabled())
            return;
        const key = this.valueKey();
        const previous = this.value();
        if (selected) {
            if (!this.isSelected(option))
                this.value.set([...previous, option]);
        }
        else {
            this.value.set(previous.filter((item) => item[key] !== option[key]));
        }
    }
    onFocusOut(event) {
        if (!this.host.nativeElement.contains(event.relatedTarget)) {
            this.touched.set(true);
        }
    }
    focus(options) {
        this.host.nativeElement.querySelector('input')?.focus(options);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiCheckboxGroup, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.26", type: UiCheckboxGroup, isStandalone: true, selector: "ui-checkbox-group", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: true, transformFunction: null }, valueKey: { classPropertyName: "valueKey", publicName: "valueKey", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, labelledBy: { classPropertyName: "labelledBy", publicName: "labelledBy", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", touched: "touchedChange" }, host: { attributes: { "role": "group" }, listeners: { "focusout": "onFocusOut($event)" }, properties: { "attr.aria-labelledby": "labelledBy() || null", "attr.aria-invalid": "invalid()" } }, ngImport: i0, template: `
    <div class="ui-options" [class.ui-options--horizontal]="orientation() === 'horizontal'">
      @for (option of options(); track option[valueKey()]) {
        <label class="ui-option">
          <ui-checkbox [value]="isSelected(option)" [disabled]="disabled()"
            (valueChange)="setSelection(option, $event)" />
          {{ option[labelKey()] }}
        </label>
      }
    </div>
  `, isInline: true, styles: [":host{display:block}.ui-options{display:flex;flex-direction:column;gap:var(--ui-spacing-sm, 8px)}.ui-options--horizontal{flex-direction:row;flex-wrap:wrap;gap:var(--ui-spacing-lg, 16px)}.ui-option{display:inline-flex;align-items:center;gap:var(--ui-spacing-sm, 8px);cursor:pointer}\n"], dependencies: [{ kind: "component", type: UiCheckbox, selector: "ui-checkbox", inputs: ["value", "disabled", "invalid", "touched", "id", "describedBy"], outputs: ["valueChange", "touchedChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiCheckboxGroup, decorators: [{
            type: Component,
            args: [{ selector: 'ui-checkbox-group', imports: [UiCheckbox], host: {
                        'role': 'group',
                        '[attr.aria-labelledby]': 'labelledBy() || null',
                        '[attr.aria-invalid]': 'invalid()',
                        '(focusout)': 'onFocusOut($event)',
                    }, template: `
    <div class="ui-options" [class.ui-options--horizontal]="orientation() === 'horizontal'">
      @for (option of options(); track option[valueKey()]) {
        <label class="ui-option">
          <ui-checkbox [value]="isSelected(option)" [disabled]="disabled()"
            (valueChange)="setSelection(option, $event)" />
          {{ option[labelKey()] }}
        </label>
      }
    </div>
  `, styles: [":host{display:block}.ui-options{display:flex;flex-direction:column;gap:var(--ui-spacing-sm, 8px)}.ui-options--horizontal{flex-direction:row;flex-wrap:wrap;gap:var(--ui-spacing-lg, 16px)}.ui-option{display:inline-flex;align-items:center;gap:var(--ui-spacing-sm, 8px);cursor:pointer}\n"] }]
        }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], labelKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelKey", required: true }] }], valueKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueKey", required: true }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }, { type: i0.Output, args: ["touchedChange"] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], labelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelledBy", required: false }] }] } });

let nextGroupId = 0;
class UiFormFieldCheckboxGroup {
    constructor() {
        this.label = input.required(...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
        this.options = input([], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
        this.labelKey = input.required(...(ngDevMode ? [{ debugName: "labelKey" }] : /* istanbul ignore next */ []));
        this.valueKey = input.required(...(ngDevMode ? [{ debugName: "valueKey" }] : /* istanbul ignore next */ []));
        this.orientation = input('vertical', ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
        this.value = model([], ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
        this.disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
        this.invalid = input(false, ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
        this.touched = model(false, ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
        this.errors = input([], ...(ngDevMode ? [{ debugName: "errors" }] : /* istanbul ignore next */ []));
        this.labelId = `ui-checkbox-group-label-${++nextGroupId}`;
        this.control = viewChild((UiCheckboxGroup), ...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    }
    showError() {
        return this.touched() && this.invalid() && this.errors().length > 0;
    }
    errorMessage() {
        return this.errors()[0]?.message ?? '';
    }
    focus(options) {
        this.control()?.focus(options);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiFormFieldCheckboxGroup, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.26", type: UiFormFieldCheckboxGroup, isStandalone: true, selector: "ui-form-field-checkbox-group", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: true, transformFunction: null }, valueKey: { classPropertyName: "valueKey", publicName: "valueKey", isSignal: true, isRequired: true, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, errors: { classPropertyName: "errors", publicName: "errors", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", touched: "touchedChange" }, viewQueries: [{ propertyName: "control", first: true, predicate: (UiCheckboxGroup), descendants: true, isSignal: true }], ngImport: i0, template: `
    <ui-label [id]="labelId">{{ label() }}</ui-label>
    <ui-checkbox-group [labelledBy]="labelId" [options]="options()" [labelKey]="labelKey()"
      [valueKey]="valueKey()" [orientation]="orientation()" [value]="value()"
      [disabled]="disabled()" [invalid]="invalid()" [touched]="touched()"
      (valueChange)="value.set($event)" (touchedChange)="touched.set($event)" />
    @if (showError()) { <ui-error [message]="errorMessage()" /> }
  `, isInline: true, dependencies: [{ kind: "component", type: UiCheckboxGroup, selector: "ui-checkbox-group", inputs: ["options", "labelKey", "valueKey", "value", "disabled", "invalid", "touched", "orientation", "labelledBy"], outputs: ["valueChange", "touchedChange"] }, { kind: "component", type: UiLabel, selector: "ui-label", inputs: ["for"] }, { kind: "component", type: UiError, selector: "ui-error", inputs: ["message", "id"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiFormFieldCheckboxGroup, decorators: [{
            type: Component,
            args: [{
                    selector: 'ui-form-field-checkbox-group',
                    imports: [UiCheckboxGroup, UiLabel, UiError],
                    template: `
    <ui-label [id]="labelId">{{ label() }}</ui-label>
    <ui-checkbox-group [labelledBy]="labelId" [options]="options()" [labelKey]="labelKey()"
      [valueKey]="valueKey()" [orientation]="orientation()" [value]="value()"
      [disabled]="disabled()" [invalid]="invalid()" [touched]="touched()"
      (valueChange)="value.set($event)" (touchedChange)="touched.set($event)" />
    @if (showError()) { <ui-error [message]="errorMessage()" /> }
  `,
                }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], labelKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelKey", required: true }] }], valueKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueKey", required: true }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }, { type: i0.Output, args: ["touchedChange"] }], errors: [{ type: i0.Input, args: [{ isSignal: true, alias: "errors", required: false }] }], control: [{ type: i0.ViewChild, args: [i0.forwardRef(() => UiCheckboxGroup), { isSignal: true }] }] } });

let nextRadioGroupId = 0;
class UiRadioGroup {
    constructor() {
        this.options = input([], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
        this.labelKey = input.required(...(ngDevMode ? [{ debugName: "labelKey" }] : /* istanbul ignore next */ []));
        this.valueKey = input.required(...(ngDevMode ? [{ debugName: "valueKey" }] : /* istanbul ignore next */ []));
        this.value = model(null, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
        this.disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
        this.invalid = input(false, ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
        this.touched = model(false, ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
        this.orientation = input('vertical', ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
        this.labelledBy = input('', ...(ngDevMode ? [{ debugName: "labelledBy" }] : /* istanbul ignore next */ []));
        this.groupName = `ui-radio-group-${++nextRadioGroupId}`;
        this.host = inject(ElementRef);
    }
    isSelected(option) {
        const selected = this.value();
        return selected !== null && selected[this.valueKey()] === option[this.valueKey()];
    }
    select(option) {
        if (!this.disabled() && !this.isSelected(option))
            this.value.set(option);
    }
    onFocusOut(event) {
        if (!this.host.nativeElement.contains(event.relatedTarget)) {
            this.touched.set(true);
        }
    }
    focus(options) {
        const selected = this.host.nativeElement.querySelector('input:checked');
        (selected ?? this.host.nativeElement.querySelector('input'))?.focus(options);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiRadioGroup, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.26", type: UiRadioGroup, isStandalone: true, selector: "ui-radio-group", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: true, transformFunction: null }, valueKey: { classPropertyName: "valueKey", publicName: "valueKey", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, labelledBy: { classPropertyName: "labelledBy", publicName: "labelledBy", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", touched: "touchedChange" }, host: { attributes: { "role": "radiogroup" }, listeners: { "focusout": "onFocusOut($event)" }, properties: { "attr.aria-labelledby": "labelledBy() || null", "attr.aria-invalid": "invalid()" } }, ngImport: i0, template: `
    <div class="ui-options" [class.ui-options--horizontal]="orientation() === 'horizontal'">
      @for (option of options(); track option[valueKey()]) {
        <label class="ui-option">
          <input type="radio" [name]="groupName" [checked]="isSelected(option)"
            [disabled]="disabled()" (change)="select(option)" />
          {{ option[labelKey()] }}
        </label>
      }
    </div>
  `, isInline: true, styles: [":host{display:block}.ui-options{display:flex;flex-direction:column;gap:var(--ui-spacing-sm, 8px)}.ui-options--horizontal{flex-direction:row;flex-wrap:wrap;gap:var(--ui-spacing-lg, 16px)}.ui-option{display:inline-flex;align-items:center;gap:var(--ui-spacing-sm, 8px);cursor:pointer}input{accent-color:var(--ui-color-primary, #175cd3)}input:focus-visible{outline:2px solid var(--ui-color-focus, #175cd3);outline-offset:2px}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiRadioGroup, decorators: [{
            type: Component,
            args: [{ selector: 'ui-radio-group', host: {
                        'role': 'radiogroup',
                        '[attr.aria-labelledby]': 'labelledBy() || null',
                        '[attr.aria-invalid]': 'invalid()',
                        '(focusout)': 'onFocusOut($event)',
                    }, template: `
    <div class="ui-options" [class.ui-options--horizontal]="orientation() === 'horizontal'">
      @for (option of options(); track option[valueKey()]) {
        <label class="ui-option">
          <input type="radio" [name]="groupName" [checked]="isSelected(option)"
            [disabled]="disabled()" (change)="select(option)" />
          {{ option[labelKey()] }}
        </label>
      }
    </div>
  `, styles: [":host{display:block}.ui-options{display:flex;flex-direction:column;gap:var(--ui-spacing-sm, 8px)}.ui-options--horizontal{flex-direction:row;flex-wrap:wrap;gap:var(--ui-spacing-lg, 16px)}.ui-option{display:inline-flex;align-items:center;gap:var(--ui-spacing-sm, 8px);cursor:pointer}input{accent-color:var(--ui-color-primary, #175cd3)}input:focus-visible{outline:2px solid var(--ui-color-focus, #175cd3);outline-offset:2px}\n"] }]
        }], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], labelKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelKey", required: true }] }], valueKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueKey", required: true }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }, { type: i0.Output, args: ["touchedChange"] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], labelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelledBy", required: false }] }] } });

let nextRadioFieldId = 0;
class UiFormFieldRadioGroup {
    constructor() {
        this.label = input.required(...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
        this.options = input([], ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
        this.labelKey = input.required(...(ngDevMode ? [{ debugName: "labelKey" }] : /* istanbul ignore next */ []));
        this.valueKey = input.required(...(ngDevMode ? [{ debugName: "valueKey" }] : /* istanbul ignore next */ []));
        this.orientation = input('vertical', ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
        this.value = model(null, ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
        this.disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
        this.invalid = input(false, ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
        this.touched = model(false, ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
        this.errors = input([], ...(ngDevMode ? [{ debugName: "errors" }] : /* istanbul ignore next */ []));
        this.labelId = `ui-radio-group-label-${++nextRadioFieldId}`;
        this.control = viewChild((UiRadioGroup), ...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    }
    showError() {
        return this.touched() && this.invalid() && this.errors().length > 0;
    }
    errorMessage() {
        return this.errors()[0]?.message ?? '';
    }
    focus(options) {
        this.control()?.focus(options);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiFormFieldRadioGroup, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.26", type: UiFormFieldRadioGroup, isStandalone: true, selector: "ui-form-field-radio-group", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, labelKey: { classPropertyName: "labelKey", publicName: "labelKey", isSignal: true, isRequired: true, transformFunction: null }, valueKey: { classPropertyName: "valueKey", publicName: "valueKey", isSignal: true, isRequired: true, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, errors: { classPropertyName: "errors", publicName: "errors", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", touched: "touchedChange" }, viewQueries: [{ propertyName: "control", first: true, predicate: (UiRadioGroup), descendants: true, isSignal: true }], ngImport: i0, template: `
    <ui-label [id]="labelId">{{ label() }}</ui-label>
    <ui-radio-group [labelledBy]="labelId" [options]="options()" [labelKey]="labelKey()"
      [valueKey]="valueKey()" [orientation]="orientation()" [value]="value()"
      [disabled]="disabled()" [invalid]="invalid()" [touched]="touched()"
      (valueChange)="value.set($event)" (touchedChange)="touched.set($event)" />
    @if (showError()) { <ui-error [message]="errorMessage()" /> }
  `, isInline: true, dependencies: [{ kind: "component", type: UiRadioGroup, selector: "ui-radio-group", inputs: ["options", "labelKey", "valueKey", "value", "disabled", "invalid", "touched", "orientation", "labelledBy"], outputs: ["valueChange", "touchedChange"] }, { kind: "component", type: UiLabel, selector: "ui-label", inputs: ["for"] }, { kind: "component", type: UiError, selector: "ui-error", inputs: ["message", "id"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: UiFormFieldRadioGroup, decorators: [{
            type: Component,
            args: [{
                    selector: 'ui-form-field-radio-group',
                    imports: [UiRadioGroup, UiLabel, UiError],
                    template: `
    <ui-label [id]="labelId">{{ label() }}</ui-label>
    <ui-radio-group [labelledBy]="labelId" [options]="options()" [labelKey]="labelKey()"
      [valueKey]="valueKey()" [orientation]="orientation()" [value]="value()"
      [disabled]="disabled()" [invalid]="invalid()" [touched]="touched()"
      (valueChange)="value.set($event)" (touchedChange)="touched.set($event)" />
    @if (showError()) { <ui-error [message]="errorMessage()" /> }
  `,
                }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], labelKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelKey", required: true }] }], valueKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueKey", required: true }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }, { type: i0.Output, args: ["touchedChange"] }], errors: [{ type: i0.Input, args: [{ isSignal: true, alias: "errors", required: false }] }], control: [{ type: i0.ViewChild, args: [i0.forwardRef(() => UiRadioGroup), { isSignal: true }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { UiAlert, UiButton, UiCheckbox, UiCheckboxGroup, UiError, UiFormFieldCheckbox, UiFormFieldCheckboxGroup, UiFormFieldInput, UiFormFieldRadioGroup, UiInput, UiLabel, UiRadioGroup };
//# sourceMappingURL=ui.mjs.map
