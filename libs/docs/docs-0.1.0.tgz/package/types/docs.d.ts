import * as _angular_core from '@angular/core';
import { FormValueControl, ValidationError } from '@angular/forms/signals';

interface DocumentMetadata {
    id?: string;
    fileName: string;
    mimeType: string;
    size: number;
    createDate: string;
    modifyDate: string;
    retentionDate: string | null;
    user?: string;
}
type DocumentState = 'NEW' | 'ADDING' | 'ADDING_FAILED' | 'DEFAULT' | 'MARKED_FOR_DELETE' | 'DELETING' | 'DELETE_FAILED';
type DocumentModelConfig = {
    initialState?: DocumentState;
    metadata: DocumentMetadata;
    file?: File;
};
interface Repository {
    upload(file: File): Promise<DocumentMetadata>;
    download(id: string): Promise<Blob>;
    remove(id: string): Promise<void>;
}
type RepositoryType = 'A' | 'B';
type SynchronizationMode = 'IMMEDIATE' | 'DEFERRED';

/** Możliwe przejścia
 * NEW -> ADDING lub NEW -> usunięcie
 * ADDING -> ADDING_FAILED lub ADDING -> DEFAULT
 * ADDING_FAILED -> ADDING lub ADDING_FAILED -> usunięcie (tak samo jak NEW)
 * DEFAULT -> MARKED_FOR_DELETE
 * MARKED_FOR_DELETE -> DELETING lub MARKED_FOR_DELETE -> DEFAULT (undo)
 * DELETING -> DELETE_FAILED lub DELETING -> usunięcie
 * DELETE_FAILED -> DELETING lub DELETE_FAILED -> DEFAULT (undo) jak w MARKED_FOR_DELETE, lub DELETE_FAILED -> usunięcie (force delete)
 */
declare class DocumentModel {
    readonly localId: string;
    readonly state: _angular_core.WritableSignal<DocumentState>;
    readonly metadata: _angular_core.WritableSignal<DocumentMetadata>;
    readonly file: _angular_core.WritableSignal<File | undefined>;
    readonly isToDelete: _angular_core.Signal<boolean>;
    readonly isToAdd: _angular_core.Signal<boolean>;
    readonly isPending: _angular_core.Signal<boolean>;
    readonly isOnlyLocal: _angular_core.Signal<boolean>;
    readonly isActive: _angular_core.Signal<boolean>;
    constructor({ initialState, metadata, file }: DocumentModelConfig);
    updateMetadata(newMetadata: Partial<DocumentMetadata>): void;
    updateFile(newFile?: File): void;
    startAdding(): void;
    completeAdding(metadata: DocumentMetadata): void;
    failAdding(): void;
    markForDelete(): void;
    undoDelete(): void;
    startDeleting(): void;
    failDeleting(): void;
    private transitionTo;
}

declare class DocumentsStore {
    private readonly _documents;
    readonly documents: _angular_core.Signal<DocumentModel[]>;
    readonly data: _angular_core.Signal<{
        id?: string;
        fileName: string;
        mimeType: string;
        size: number;
        createDate: string;
        modifyDate: string;
        retentionDate: string | null;
        user?: string;
    }[]>;
    replace(documents: DocumentMetadata[]): void;
    getDocumentByLocalId(localId: string): DocumentModel | undefined;
    add(file: File): DocumentModel;
    remove(localId: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DocumentsStore, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<DocumentsStore>;
}

declare class Documents implements FormValueControl<DocumentMetadata[]> {
    readonly value: _angular_core.ModelSignal<DocumentMetadata[]>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly invalid: _angular_core.InputSignal<boolean>;
    readonly touched: _angular_core.InputSignal<boolean>;
    readonly errors: _angular_core.InputSignal<readonly ValidationError.WithOptionalFieldTree[]>;
    readonly touch: _angular_core.OutputEmitterRef<void>;
    readonly repositoryType: _angular_core.InputSignal<RepositoryType>;
    readonly synchronizationMode: _angular_core.InputSignal<SynchronizationMode>;
    readonly title: _angular_core.InputSignal<string>;
    protected readonly store: DocumentsStore;
    private readonly repositoryFactory;
    private readonly fileDownloadService;
    protected formatDate(date: string): string;
    private readonly host;
    private appliedValue?;
    private externalRevision;
    readonly searchQuery: _angular_core.WritableSignal<string>;
    private readonly committing;
    protected readonly actionsDisabled: _angular_core.Signal<boolean>;
    readonly isSynchronized: _angular_core.Signal<boolean>;
    private readonly activeRepository;
    readonly filteredDocuments: _angular_core.Signal<DocumentModel[]>;
    constructor();
    protected handleFocusOut(event: FocusEvent): void;
    private applyFormValue;
    private publishValue;
    downloadDocument(localId: string): Promise<void>;
    uploadDocument(event: Event): Promise<void>;
    undoDelete(localId: string): void;
    removeDocument(localId: string): Promise<void>;
    addFile(file: File): Promise<void>;
    commit(): Promise<void>;
    private synchronizePendingDocuments;
    private addDocumentRemotely;
    private deleteDocumentRemotely;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Documents, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Documents, "app-documents", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "touched": { "alias": "touched"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; "isSignal": true; }; "repositoryType": { "alias": "repositoryType"; "required": false; "isSignal": true; }; "synchronizationMode": { "alias": "synchronizationMode"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touch": "touch"; }, never, never, true, never>;
}

export { Documents };
export type { DocumentMetadata, Repository, RepositoryType, SynchronizationMode };
//# sourceMappingURL=docs.d.ts.map
