import * as i0 from '@angular/core';
import { inject, Injectable, signal, computed, model, input, output, ElementRef, effect, untracked, Component } from '@angular/core';
import { UiAlert, UiButton, UiInput } from 'ui';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

class RepositoryAService {
    http = inject(HttpClient);
    baseUrl = 'http://localhost:3000/api/files';
    async download(id) {
        return firstValueFrom(this.http.get(`${this.baseUrl}/${id}/download`, {
            responseType: 'blob',
        }));
    }
    async upload(file) {
        const formData = new FormData();
        formData.append('file', file);
        const response = await firstValueFrom(this.http.post(this.baseUrl, formData));
        return {
            id: response.id,
            fileName: response.filename,
            mimeType: response.mimeType,
            size: response.size,
            createDate: response.createDate,
            modifyDate: response.modifyDate,
            retentionDate: response.retentionDate,
            user: response.user,
        };
    }
    async remove(id) {
        await firstValueFrom(this.http.delete(`${this.baseUrl}/${id}`));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: RepositoryAService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: RepositoryAService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: RepositoryAService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class RepositoryFactory {
    repositoryA = inject(RepositoryAService);
    get(type) {
        switch (type) {
            case 'A':
                return this.repositoryA;
            case 'B':
                return this.repositoryA; // Placeholder for RepositoryBService, which is not implemented yet
            default:
                throw new Error(`Unknown repository type: ${type}`);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: RepositoryFactory, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: RepositoryFactory, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: RepositoryFactory, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class FileDownloadService {
    url = null;
    ngOnDestroy() {
        this.releaseUrl();
    }
    save(blob, fileName) {
        if (!!this.url)
            URL.revokeObjectURL(this.url);
        this.url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = this.url;
        link.download = fileName;
        link.click();
    }
    releaseUrl() {
        if (!this.url)
            return;
        URL.revokeObjectURL(this.url);
        this.url = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: FileDownloadService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: FileDownloadService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: FileDownloadService, decorators: [{
            type: Injectable
        }] });

/** Możliwe przejścia
 * NEW -> ADDING lub NEW -> usunięcie
 * ADDING -> ADDING_FAILED lub ADDING -> DEFAULT
 * ADDING_FAILED -> ADDING lub ADDING_FAILED -> usunięcie (tak samo jak NEW)
 * DEFAULT -> MARKED_FOR_DELETE
 * MARKED_FOR_DELETE -> DELETING lub MARKED_FOR_DELETE -> DEFAULT (undo)
 * DELETING -> DELETE_FAILED lub DELETING -> usunięcie
 * DELETE_FAILED -> DELETING lub DELETE_FAILED -> DEFAULT (undo) jak w MARKED_FOR_DELETE, lub DELETE_FAILED -> usunięcie (force delete)
 */
class DocumentModel {
    localId;
    state = signal('NEW', ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    metadata = signal({}, ...(ngDevMode ? [{ debugName: "metadata" }] : /* istanbul ignore next */ []));
    file = signal(undefined, ...(ngDevMode ? [{ debugName: "file" }] : /* istanbul ignore next */ []));
    isToDelete = computed(() => ['MARKED_FOR_DELETE', 'DELETE_FAILED'].includes(this.state()), ...(ngDevMode ? [{ debugName: "isToDelete" }] : /* istanbul ignore next */ []));
    isToAdd = computed(() => ['NEW', 'ADDING_FAILED'].includes(this.state()), ...(ngDevMode ? [{ debugName: "isToAdd" }] : /* istanbul ignore next */ []));
    isPending = computed(() => this.isToAdd() || this.isToDelete(), ...(ngDevMode ? [{ debugName: "isPending" }] : /* istanbul ignore next */ []));
    isOnlyLocal = this.isToAdd;
    isActive = computed(() => ['NEW', 'ADDING', 'ADDING_FAILED', 'DEFAULT'].includes(this.state()), ...(ngDevMode ? [{ debugName: "isActive" }] : /* istanbul ignore next */ [])); // czy jest nadal aktualny z perspektywy stanu formularza, traktując odroczone operacje jakby się wykonaly - jeśli ma być usunięty to tu już dokument nie jest uwzględniany, jeśli ma być dodany to już jest uznawany
    constructor({ initialState = 'NEW', metadata, file }) {
        this.localId = crypto.randomUUID();
        this.state.set(initialState);
        this.metadata.set(metadata);
        this.file.set(file);
    }
    updateMetadata(newMetadata) {
        this.metadata.update((current) => ({ ...current, ...newMetadata }));
    }
    updateFile(newFile) {
        this.file.set(newFile);
    }
    startAdding() {
        this.transitionTo('ADDING', ['NEW', 'ADDING_FAILED']);
    }
    completeAdding(metadata) {
        this.transitionTo('DEFAULT', ['ADDING']);
        this.updateMetadata({ ...metadata });
        this.updateFile();
    }
    failAdding() {
        this.transitionTo('ADDING_FAILED', ['ADDING']);
    }
    markForDelete() {
        this.transitionTo('MARKED_FOR_DELETE', ['DEFAULT']);
    }
    undoDelete() {
        this.transitionTo('DEFAULT', ['MARKED_FOR_DELETE', 'DELETE_FAILED']);
    }
    startDeleting() {
        this.transitionTo('DELETING', ['DEFAULT', 'MARKED_FOR_DELETE', 'DELETE_FAILED']);
    }
    failDeleting() {
        this.transitionTo('DELETE_FAILED', ['DELETING']);
    }
    transitionTo(nextState, allowedFrom) {
        const currentState = this.state();
        if (!allowedFrom.includes(currentState))
            throw new Error(`Niedozwolona zmiana stanu dokumentu: ${currentState} → ${nextState}`);
        this.state.set(nextState);
    }
}

class DocumentsStore {
    _documents = signal([], ...(ngDevMode ? [{ debugName: "_documents" }] : /* istanbul ignore next */ []));
    documents = this._documents.asReadonly();
    data = computed(() => this.documents()
        .filter((document) => document.isActive())
        .map((document) => ({ ...document.metadata() })), ...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    replace(documents) {
        this._documents.set(documents.map((metadata) => new DocumentModel({ initialState: 'DEFAULT', metadata: { ...metadata } })));
    }
    getDocumentByLocalId(localId) {
        return this.documents().find((document) => document.localId === localId);
    }
    add(file) {
        const now = new Date().toISOString();
        const metadata = {
            fileName: file.name,
            mimeType: file.type || 'application/octet-stream',
            size: file.size,
            createDate: now,
            modifyDate: now,
            retentionDate: null,
        };
        const newDocument = new DocumentModel({ initialState: 'NEW', metadata, file });
        this._documents.update((current) => [...current, newDocument]);
        return newDocument;
    }
    remove(localId) {
        this._documents.update((current) => [...current.filter((el) => el.localId !== localId)]);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: DocumentsStore, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: DocumentsStore });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: DocumentsStore, decorators: [{
            type: Injectable
        }] });

class Documents {
    value = model([], ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    invalid = input(false, ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
    touched = input(false, ...(ngDevMode ? [{ debugName: "touched" }] : /* istanbul ignore next */ []));
    errors = input([], ...(ngDevMode ? [{ debugName: "errors" }] : /* istanbul ignore next */ []));
    touch = output();
    repositoryType = input('A', ...(ngDevMode ? [{ debugName: "repositoryType" }] : /* istanbul ignore next */ []));
    synchronizationMode = input('IMMEDIATE', ...(ngDevMode ? [{ debugName: "synchronizationMode" }] : /* istanbul ignore next */ []));
    title = input('', ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    store = inject(DocumentsStore);
    repositoryFactory = inject(RepositoryFactory);
    fileDownloadService = inject(FileDownloadService);
    formatDate(date) {
        if (!date || Number.isNaN(new Date(date).getTime()))
            return '';
        return new Intl.DateTimeFormat('sv-SE', {
            timeZone: 'Europe/Warsaw',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            hourCycle: 'h23',
        }).format(new Date(date));
    }
    host = inject(ElementRef);
    appliedValue;
    externalRevision = 0;
    searchQuery = signal('', ...(ngDevMode ? [{ debugName: "searchQuery" }] : /* istanbul ignore next */ []));
    committing = signal(false, ...(ngDevMode ? [{ debugName: "committing" }] : /* istanbul ignore next */ []));
    actionsDisabled = computed(() => this.disabled() || this.committing(), ...(ngDevMode ? [{ debugName: "actionsDisabled" }] : /* istanbul ignore next */ []));
    isSynchronized = computed(() => this.store.documents().every((document) => document.state() === 'DEFAULT'), ...(ngDevMode ? [{ debugName: "isSynchronized" }] : /* istanbul ignore next */ []));
    activeRepository = computed(() => this.repositoryFactory.get(this.repositoryType()), ...(ngDevMode ? [{ debugName: "activeRepository" }] : /* istanbul ignore next */ []));
    filteredDocuments = computed(() => {
        const query = this.searchQuery().trim().toLocaleLowerCase();
        return this.store.documents().filter((document) => document.metadata().fileName.toLocaleLowerCase().includes(query));
    }, ...(ngDevMode ? [{ debugName: "filteredDocuments" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const value = this.value();
            untracked(() => this.applyFormValue(value));
        });
    }
    handleFocusOut(event) {
        if (!this.disabled() && !this.host.nativeElement.contains(event.relatedTarget)) {
            this.touch.emit();
        }
    }
    applyFormValue(value = this.value()) {
        if (value === this.appliedValue)
            return;
        this.externalRevision++;
        this.appliedValue = value;
        this.store.replace(value);
    }
    publishValue() {
        // Keep the store's Files and pending deletes when Signal Forms echoes this value.
        const value = this.store.data();
        this.appliedValue = value;
        this.value.set(value);
    }
    async downloadDocument(localId) {
        if (this.actionsDisabled())
            return;
        this.applyFormValue();
        const document = this.store.getDocumentByLocalId(localId);
        if (!document)
            return;
        const file = document.file();
        const metadata = document.metadata();
        try {
            let blob;
            if (file) {
                blob = file;
            }
            else {
                if (!metadata.id) {
                    throw new Error(`Missing repository ID for document ${localId}`);
                }
                const repository = this.activeRepository();
                blob = await repository.download(metadata.id);
            }
            this.fileDownloadService.save(blob, metadata.fileName);
        }
        catch (error) {
            console.error('Document download failed:', error);
        }
    }
    async uploadDocument(event) {
        const input = event.target;
        const file = input.files?.item(0);
        if (!file)
            return;
        try {
            await this.addFile(file);
        }
        catch (error) {
            console.error('Failed to add document:', error);
        }
        finally {
            input.value = '';
        }
    }
    undoDelete(localId) {
        if (this.actionsDisabled())
            return;
        this.applyFormValue();
        const document = this.store.getDocumentByLocalId(localId);
        if (!document?.isToDelete())
            return;
        document.undoDelete();
        this.publishValue();
    }
    async removeDocument(localId) {
        if (this.actionsDisabled())
            return;
        this.applyFormValue();
        const document = this.store.getDocumentByLocalId(localId);
        if (!document)
            return;
        if (document.isOnlyLocal()) {
            this.store.remove(document.localId);
        }
        else if (document.state() === 'DEFAULT') {
            document.markForDelete();
        }
        else {
            return;
        }
        this.publishValue();
        try {
            if (this.synchronizationMode() === 'IMMEDIATE' && document.isToDelete()) {
                await this.deleteDocumentRemotely(localId, this.activeRepository());
            }
        }
        catch (error) {
            console.error(`Delete failed, localId: ${document.localId}, ${error}`);
        }
    }
    async addFile(file) {
        if (this.actionsDisabled())
            return;
        this.applyFormValue();
        const document = this.store.add(file);
        this.publishValue();
        try {
            if (this.synchronizationMode() === 'IMMEDIATE') {
                await this.addDocumentRemotely(document.localId, this.activeRepository());
            }
        }
        catch (error) {
            console.error('Upload failed:', error);
        }
    }
    async commit() {
        if (this.committing())
            throw new Error('Commit already in progress');
        if (this.disabled())
            throw new Error('The documents field is disabled.');
        this.applyFormValue();
        const revision = this.externalRevision;
        this.committing.set(true);
        try {
            await this.synchronizePendingDocuments();
            this.applyFormValue();
            if (revision !== this.externalRevision) {
                throw new Error('The document list was replaced during synchronization.');
            }
        }
        finally {
            this.committing.set(false);
        }
    }
    async synchronizePendingDocuments() {
        const repository = this.activeRepository();
        const pending = this.store.documents().filter((document) => document.isPending());
        const results = await Promise.allSettled(pending.map(async (document) => {
            if (document.isToAdd())
                return this.addDocumentRemotely(document.localId, repository);
            else if (document.isToDelete())
                return this.deleteDocumentRemotely(document.localId, repository);
            throw new Error(`Cannot synchronize document ${document.localId} in state ${document.state()}`);
        }));
        const failures = results.filter((result) => result.status === 'rejected');
        if (failures.length > 0) {
            throw new AggregateError(failures.map((result) => result.reason), `Failed to synchronize ${failures.length} documents`);
        }
    }
    async addDocumentRemotely(localId, repository) {
        const document = this.store.getDocumentByLocalId(localId);
        if (!document)
            throw new Error(`Cannot find document: ${localId}`);
        const file = document.file();
        if (!file)
            throw new Error(`Missing file for document ${localId}`);
        document.startAdding();
        try {
            const metadata = await repository.upload(file);
            this.applyFormValue();
            if (this.store.getDocumentByLocalId(localId) !== document)
                return;
            document.completeAdding(metadata);
            this.publishValue();
        }
        catch (error) {
            document.failAdding();
            throw error;
        }
    }
    async deleteDocumentRemotely(localId, repository) {
        const document = this.store.getDocumentByLocalId(localId);
        if (!document)
            throw new Error(`Cannot find document: ${localId}`);
        const metadata = document.metadata();
        if (!metadata.id)
            throw new Error(`Missing repository ID for ${localId}`);
        document.startDeleting();
        try {
            await repository.remove(metadata.id);
            this.store.remove(document.localId);
        }
        catch (error) {
            document.failDeleting();
            throw error;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: Documents, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.26", type: Documents, isStandalone: true, selector: "app-documents", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, touched: { classPropertyName: "touched", publicName: "touched", isSignal: true, isRequired: false, transformFunction: null }, errors: { classPropertyName: "errors", publicName: "errors", isSignal: true, isRequired: false, transformFunction: null }, repositoryType: { classPropertyName: "repositoryType", publicName: "repositoryType", isSignal: true, isRequired: false, transformFunction: null }, synchronizationMode: { classPropertyName: "synchronizationMode", publicName: "synchronizationMode", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", touch: "touch" }, host: { listeners: { "focusout": "handleFocusOut($event)" } }, providers: [DocumentsStore, FileDownloadService], ngImport: i0, template: "<section class=\"documents__container\" [attr.aria-invalid]=\"invalid() ? true : null\">\n  <h2>{{ title() }}</h2>\n  @if (invalid()) {\n    @for (error of errors(); track $index) {\n      @if (error.message) {\n        <ui-alert variant=\"error\">{{ error.message }}</ui-alert>\n      }\n    }\n  }\n  <nav class=\"documents__actions\">\n    <ui-input\n      type=\"search\"\n      [disabled]=\"disabled()\"\n      placeholder=\"Szukaj po nazwie pliku...\"\n      [value]=\"searchQuery()\"\n      (valueChange)=\"searchQuery.set($event)\"\n    />\n    <input #fileInput type=\"file\" hidden [disabled]=\"actionsDisabled()\" (change)=\"uploadDocument($event)\" />\n    <ui-button variant=\"primary\" size=\"default\" (clicked)=\"fileInput.click()\" [disabled]=\"actionsDisabled()\">Dodaj dokument</ui-button>\n  </nav>\n  <table class=\"documents-table\">\n    <colgroup>\n      <col class=\"col-state\" />\n      <col />\n      <col class=\"col-user\" />\n      <col class=\"col-date\" />\n      <col class=\"col-actions\" />\n    </colgroup>\n    <thead>\n      <tr>\n        <th>Status</th>\n        <th>Nazwa pliku</th>\n        <th>U\u017Cytkownik</th>\n        <th>Data dodania</th>\n        <th>Akcje</th>\n      </tr>\n    </thead>\n    <tbody>\n      @for (document of filteredDocuments(); track document.localId) {\n        <tr>\n          <td>{{ document.state() }}</td>\n          <td>{{ document.metadata().fileName }}</td>\n          <td>{{ document.metadata().user }}</td>\n          <td>{{ formatDate(document.metadata().createDate) }}</td>\n          <td>\n            @if (document.state() === 'MARKED_FOR_DELETE' || document.state() === 'DELETE_FAILED') {\n              <ui-button variant=\"secondary\" size=\"mini\" [disabled]=\"actionsDisabled()\" (clicked)=\"undoDelete(document.localId)\">Cofnij</ui-button>\n            } @else {\n              <ui-button variant=\"secondary\" size=\"mini\"\n                [disabled]=\"document.state() === 'ADDING' || document.state() === 'DELETING' || actionsDisabled()\"\n                (clicked)=\"removeDocument(document.localId)\"\n              >\n                Usu\u0144\n              </ui-button>\n            }\n            <ui-button variant=\"secondary\" size=\"mini\" [disabled]=\"document.state() === 'DELETING' || actionsDisabled()\" (clicked)=\"downloadDocument(document.localId)\">\n              Pobierz\n            </ui-button>\n          </td>\n        </tr>\n      }\n    </tbody>\n  </table>\n</section>\n", styles: [".documents__container{display:flex;flex-direction:column;gap:1rem;padding:1rem}.documents__container th{text-align:left}.documents__actions{display:flex;align-items:center;gap:.5rem}.documents__actions ui-input{flex:1;min-width:0}.documents-table td:last-child{white-space:nowrap}.documents-table td:last-child ui-button{margin-right:var(--ui-spacing-xs, 4px)}.documents-table{width:100%;table-layout:fixed}.col-state,.col-user{width:100px}.col-date{width:150px}.col-actions{width:200px}.documents__container[aria-invalid=true]{outline:1px solid #b42318;outline-offset:-1px}\n"], dependencies: [{ kind: "component", type: UiAlert, selector: "ui-alert", inputs: ["variant"] }, { kind: "component", type: UiButton, selector: "ui-button", inputs: ["variant", "size", "type", "disabled"], outputs: ["clicked"] }, { kind: "component", type: UiInput, selector: "ui-input", inputs: ["value", "type", "placeholder", "disabled", "readonly", "invalid", "size", "id", "describedBy", "touched"], outputs: ["valueChange", "touchedChange"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.26", ngImport: i0, type: Documents, decorators: [{
            type: Component,
            args: [{ imports: [UiAlert, UiButton, UiInput], providers: [DocumentsStore, FileDownloadService], selector: 'app-documents', host: { '(focusout)': 'handleFocusOut($event)' }, template: "<section class=\"documents__container\" [attr.aria-invalid]=\"invalid() ? true : null\">\n  <h2>{{ title() }}</h2>\n  @if (invalid()) {\n    @for (error of errors(); track $index) {\n      @if (error.message) {\n        <ui-alert variant=\"error\">{{ error.message }}</ui-alert>\n      }\n    }\n  }\n  <nav class=\"documents__actions\">\n    <ui-input\n      type=\"search\"\n      [disabled]=\"disabled()\"\n      placeholder=\"Szukaj po nazwie pliku...\"\n      [value]=\"searchQuery()\"\n      (valueChange)=\"searchQuery.set($event)\"\n    />\n    <input #fileInput type=\"file\" hidden [disabled]=\"actionsDisabled()\" (change)=\"uploadDocument($event)\" />\n    <ui-button variant=\"primary\" size=\"default\" (clicked)=\"fileInput.click()\" [disabled]=\"actionsDisabled()\">Dodaj dokument</ui-button>\n  </nav>\n  <table class=\"documents-table\">\n    <colgroup>\n      <col class=\"col-state\" />\n      <col />\n      <col class=\"col-user\" />\n      <col class=\"col-date\" />\n      <col class=\"col-actions\" />\n    </colgroup>\n    <thead>\n      <tr>\n        <th>Status</th>\n        <th>Nazwa pliku</th>\n        <th>U\u017Cytkownik</th>\n        <th>Data dodania</th>\n        <th>Akcje</th>\n      </tr>\n    </thead>\n    <tbody>\n      @for (document of filteredDocuments(); track document.localId) {\n        <tr>\n          <td>{{ document.state() }}</td>\n          <td>{{ document.metadata().fileName }}</td>\n          <td>{{ document.metadata().user }}</td>\n          <td>{{ formatDate(document.metadata().createDate) }}</td>\n          <td>\n            @if (document.state() === 'MARKED_FOR_DELETE' || document.state() === 'DELETE_FAILED') {\n              <ui-button variant=\"secondary\" size=\"mini\" [disabled]=\"actionsDisabled()\" (clicked)=\"undoDelete(document.localId)\">Cofnij</ui-button>\n            } @else {\n              <ui-button variant=\"secondary\" size=\"mini\"\n                [disabled]=\"document.state() === 'ADDING' || document.state() === 'DELETING' || actionsDisabled()\"\n                (clicked)=\"removeDocument(document.localId)\"\n              >\n                Usu\u0144\n              </ui-button>\n            }\n            <ui-button variant=\"secondary\" size=\"mini\" [disabled]=\"document.state() === 'DELETING' || actionsDisabled()\" (clicked)=\"downloadDocument(document.localId)\">\n              Pobierz\n            </ui-button>\n          </td>\n        </tr>\n      }\n    </tbody>\n  </table>\n</section>\n", styles: [".documents__container{display:flex;flex-direction:column;gap:1rem;padding:1rem}.documents__container th{text-align:left}.documents__actions{display:flex;align-items:center;gap:.5rem}.documents__actions ui-input{flex:1;min-width:0}.documents-table td:last-child{white-space:nowrap}.documents-table td:last-child ui-button{margin-right:var(--ui-spacing-xs, 4px)}.documents-table{width:100%;table-layout:fixed}.col-state,.col-user{width:100px}.col-date{width:150px}.col-actions{width:200px}.documents__container[aria-invalid=true]{outline:1px solid #b42318;outline-offset:-1px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], touched: [{ type: i0.Input, args: [{ isSignal: true, alias: "touched", required: false }] }], errors: [{ type: i0.Input, args: [{ isSignal: true, alias: "errors", required: false }] }], touch: [{ type: i0.Output, args: ["touch"] }], repositoryType: [{ type: i0.Input, args: [{ isSignal: true, alias: "repositoryType", required: false }] }], synchronizationMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "synchronizationMode", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { Documents };
//# sourceMappingURL=docs.mjs.map
